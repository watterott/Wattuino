
This is libusb-win32 (http://libusb-win32.sourceforge.net) version 1.2.6.0. 
Libusb-win32 is a library that allows userspace application to access USB 
devices on Windows operation systems (Win2k, WinXP, Vista, Win7). 
It is derived from and fully API compatible to libusb available at 
http://libusb.sourceforge.net.

For more information visit the project's web site at:

http://libusb-win32.sourceforge.net
http://sourceforge.net/projects/libusb-win32

